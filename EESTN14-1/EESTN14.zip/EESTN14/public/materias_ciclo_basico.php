<?php
require_once '../src/config.php';

// Obtener materias de ciclo básico
$stmt = $pdo->query("
    SELECT * FROM materias 
    WHERE especialidad = 'Ciclo Basico' AND activa = 1 
    ORDER BY año, categoria, tipo, nombre
");
$materias = $stmt->fetchAll();

// Agrupar materias por año
$materias_por_año = [];
foreach ($materias as $materia) {
    $materias_por_año[$materia['año']][] = $materia;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materias del Ciclo Básico - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .year-section {
            margin-bottom: 40px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
        }
        
        .year-title {
            font-size: 1.5em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            background: #1976d2;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }
        
        .category-section {
            margin-bottom: 25px;
        }
        
        .category-title {
            font-size: 1.2em;
            font-weight: bold;
            color: #34495e;
            margin-bottom: 15px;
            padding: 8px 15px;
            background: #ecf0f1;
            border-radius: 5px;
        }
        
        .type-section {
            margin-bottom: 20px;
        }
        
        .type-title {
            font-size: 1.1em;
            font-weight: bold;
            color: #7f8c8d;
            margin-bottom: 10px;
            padding: 5px 10px;
            background: #bdc3c7;
            color: white;
            border-radius: 3px;
            display: inline-block;
        }
        
        .materias-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .materia-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            border-left: 4px solid #1976d2;
            transition: transform 0.2s;
        }
        
        .materia-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }
        
        .materia-card.taller {
            border-left-color: #e74c3c;
        }
        
        .materia-card.aula {
            border-left-color: #1976d2;
        }
        
        .materia-nombre {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .materia-info {
            font-size: 0.9em;
            color: #7f8c8d;
            margin-bottom: 5px;
        }
        
        .materia-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: #1976d2;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        
        .materia-link:hover {
            background: #1565c0;
        }
        
        .tipo-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 10px;
        }
        
        .tipo-aula {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .tipo-taller {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .back-link {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .back-link a {
            display: inline-block;
            padding: 10px 20px;
            background: #95a5a6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .back-link a:hover {
            background: #7f8c8d;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="materias_ciclo_basico.php">Ciclo Básico</a></li>
                    <li><a href="ciclo_superior.php">Ciclo Superior</a></li>
                    <li><a href="modelos_examen.php">Modelos de Examen</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="header">
                <h1>Ciclo Básico</h1>
                <p>Plan de estudios del Ciclo Básico de Educación Secundaria Técnica</p>
            </div>
            
            <div class="back-link">
                <a href="index.php">← Volver al Inicio</a>
            </div>
            
            <?php foreach ($materias_por_año as $año => $materias_año): ?>
            <div class="year-section">
                <div class="year-title"><?php echo $año; ?>° Año</div>
                
                <?php
                // Agrupar por categoría
                $materias_por_categoria = [];
                foreach ($materias_año as $materia) {
                    $materias_por_categoria[$materia['categoria']][] = $materia;
                }
                
                foreach ($materias_por_categoria as $categoria => $materias_categoria):
                ?>
                <div class="category-section">
                    <div class="category-title"><?php echo $categoria; ?></div>
                    
                    <?php
                    // Agrupar por tipo
                    $materias_por_tipo = [];
                    foreach ($materias_categoria as $materia) {
                        $materias_por_tipo[$materia['tipo']][] = $materia;
                    }
                    
                    foreach ($materias_por_tipo as $tipo => $materias_tipo):
                    ?>
                    <div class="type-section">
                        <div class="type-title">
                            <?php echo $tipo; ?>
                            <span class="tipo-badge tipo-<?php echo strtolower($tipo); ?>">
                                <?php echo $tipo; ?>
                            </span>
                        </div>
                        
                        <div class="materias-grid">
                            <?php foreach ($materias_tipo as $materia): ?>
                            <div class="materia-card <?php echo strtolower($materia['tipo']); ?>">
                                <div class="materia-nombre">
                                    <?php echo htmlspecialchars($materia['nombre']); ?>
                                </div>
                                <div class="materia-info">
                                    <strong>CHT:</strong> <?php echo $materia['cht']; ?> | 
                                    <strong>CHS:</strong> <?php echo $materia['chs']; ?>
                                </div>
                                <div class="materia-info">
                                    <strong>Categoría:</strong> <?php echo $materia['categoria']; ?>
                                </div>
                                <a href="materia_detalle.php?id=<?php echo $materia['Id']; ?>" class="materia-link">
                                    Ver Detalles y Modelos
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Ciclo Básico</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
</body>
</html>
