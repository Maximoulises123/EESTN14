<?php
require_once '../src/config.php';

// Verificar si el usuario es director
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'director') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// Procesar acciones
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'asignar_materia') {
        $profesor_id = $_POST['profesor_id'] ?? '';
        $materia_id = $_POST['materia_id'] ?? '';
        $año_academico = $_POST['año_academico'] ?? date('Y');
        
        if ($profesor_id && $materia_id) {
            // Verificar si ya existe la asignación
            $stmt = $pdo->prepare("SELECT Id FROM profesor_materia WHERE profesor_id = ? AND materia_id = ? AND año_academico = ?");
            $stmt->execute([$profesor_id, $materia_id, $año_academico]);
            
            if (!$stmt->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO profesor_materia (profesor_id, materia_id, año_academico, activo) VALUES (?, ?, ?, 1)");
                if ($stmt->execute([$profesor_id, $materia_id, $año_academico])) {
                    $success = 'Materia asignada correctamente';
                } else {
                    $error = 'Error al asignar la materia';
                }
            } else {
                $error = 'Esta materia ya está asignada a este profesor para este año';
            }
        } else {
            $error = 'Seleccione un profesor y una materia';
        }
    }
    
    if ($action === 'desasignar_materia') {
        $id = $_POST['id'] ?? '';
        
        if ($id) {
            $stmt = $pdo->prepare("UPDATE profesor_materia SET activo = 0 WHERE Id = ?");
            if ($stmt->execute([$id])) {
                $success = 'Materia desasignada correctamente';
            } else {
                $error = 'Error al desasignar la materia';
            }
        }
    }
}

// Obtener profesores activos
$stmt = $pdo->query("SELECT * FROM profesores WHERE activo = 1 ORDER BY apellido, nombre");
$profesores = $stmt->fetchAll();

// Obtener materias activas
$stmt = $pdo->query("SELECT * FROM materias WHERE activa = 1 ORDER BY especialidad, año, nombre");
$materias = $stmt->fetchAll();

// Obtener asignaciones actuales
$stmt = $pdo->query("
    SELECT pm.*, p.nombre as profesor_nombre, p.apellido as profesor_apellido, 
           m.nombre as materia_nombre, m.especialidad, m.año as materia_año
    FROM profesor_materia pm
    JOIN profesores p ON pm.profesor_id = p.Id
    JOIN materias m ON pm.materia_id = m.Id
    WHERE pm.activo = 1
    ORDER BY p.apellido, p.nombre, m.especialidad, m.año, m.nombre
");
$asignaciones = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Materias - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-danger {
            background: #e74c3c;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .table tr:hover {
            background-color: #f5f5f5;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 500px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .especialidad-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-right: 5px;
        }
        
        .especialidad-ciclo-basico {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .especialidad-programacion {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .especialidad-informatica {
            background: #e8f5e8;
            color: #388e3c;
        }
        
        .especialidad-alimentos {
            background: #fff3e0;
            color: #f57c00;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="admin_panel.php">Panel Admin</a></li>
                    <li><a href="gestionar_profesores.php">Profesores</a></li>
                    <li><a href="asignar_materias.php">Asignar Materias</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <span>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="header">
                <h1>Asignar Materias a Profesores</h1>
                <p>Gestiona las asignaciones de materias por año académico</p>
            </div>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div style="text-align: center; margin-bottom: 20px;">
                <button onclick="abrirModalAsignar()" class="btn btn-success">Asignar Nueva Materia</button>
                <a href="admin_panel.php" class="btn">Volver al Panel</a>
            </div>
            
            <h3>Asignaciones Actuales</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Profesor</th>
                        <th>Materia</th>
                        <th>Especialidad</th>
                        <th>Año</th>
                        <th>Año Académico</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($asignaciones as $asignacion): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($asignacion['profesor_apellido'] . ', ' . $asignacion['profesor_nombre']); ?></td>
                        <td><?php echo htmlspecialchars($asignacion['materia_nombre']); ?></td>
                        <td>
                            <span class="especialidad-badge especialidad-<?php echo strtolower(str_replace(' ', '-', $asignacion['especialidad'])); ?>">
                                <?php echo htmlspecialchars($asignacion['especialidad']); ?>
                            </span>
                        </td>
                        <td><?php echo $asignacion['materia_año']; ?>°</td>
                        <td><?php echo $asignacion['año_academico']; ?></td>
                        <td>
                            <button onclick="desasignarMateria(<?php echo $asignacion['Id']; ?>)" class="btn btn-danger">Desasignar</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <!-- Modal para asignar materia -->
    <div id="modalAsignar" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarModalAsignar()">&times;</span>
            <h3>Asignar Materia a Profesor</h3>
            <form method="POST">
                <input type="hidden" name="action" value="asignar_materia">
                
                <div class="form-group">
                    <label for="profesor_id">Profesor:</label>
                    <select name="profesor_id" id="profesor_id" required>
                        <option value="">Seleccionar profesor</option>
                        <?php foreach ($profesores as $profesor): ?>
                            <option value="<?php echo $profesor['Id']; ?>">
                                <?php echo htmlspecialchars($profesor['apellido'] . ', ' . $profesor['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="materia_id">Materia:</label>
                    <select name="materia_id" id="materia_id" required>
                        <option value="">Seleccionar materia</option>
                        <?php 
                        $especialidad_actual = '';
                        foreach ($materias as $materia): 
                            if ($materia['especialidad'] !== $especialidad_actual) {
                                $especialidad_actual = $materia['especialidad'];
                                echo '<optgroup label="' . htmlspecialchars($especialidad_actual) . '">';
                            }
                        ?>
                            <option value="<?php echo $materia['Id']; ?>">
                                <?php echo $materia['año']; ?>° - <?php echo htmlspecialchars($materia['nombre']); ?>
                            </option>
                        <?php 
                            if (next($materias) && $materias[key($materias)]['especialidad'] !== $especialidad_actual) {
                                echo '</optgroup>';
                            }
                        endforeach; 
                        echo '</optgroup>';
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="año_academico">Año Académico:</label>
                    <input type="number" name="año_academico" id="año_academico" value="<?php echo date('Y'); ?>" min="2020" max="2030" required>
                </div>
                
                <button type="submit" class="btn btn-success">Asignar Materia</button>
            </form>
        </div>
    </div>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Asignación de Materias</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
    
    <script>
        function abrirModalAsignar() {
            document.getElementById('modalAsignar').style.display = 'block';
        }
        
        function cerrarModalAsignar() {
            document.getElementById('modalAsignar').style.display = 'none';
        }
        
        function desasignarMateria(id) {
            if (confirm('¿Está seguro de que desea desasignar esta materia?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="desasignar_materia">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Cerrar modal al hacer clic fuera
        window.onclick = function(event) {
            const modal = document.getElementById('modalAsignar');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
