<?php
require_once '../src/config.php';

// Verificar si el usuario es profesor
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'profesor') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// Obtener materias asignadas al profesor
$stmt = $pdo->prepare("
    SELECT m.*, pm.año_academico
    FROM materias m
    JOIN profesor_materia pm ON m.Id = pm.materia_id
    WHERE pm.profesor_id = ? AND pm.activo = 1 AND m.activa = 1
    ORDER BY m.especialidad, m.año, m.nombre
");
$stmt->execute([$_SESSION['usuario_id']]);
$materias_asignadas = $stmt->fetchAll();

// Procesar subida de archivo
if ($_POST) {
    $materia_id = $_POST['materia_id'] ?? '';
    $titulo = trim($_POST['titulo'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    
    if ($materia_id && $titulo && isset($_FILES['archivo'])) {
        // Verificar que la materia esté asignada al profesor
        $materia_valida = false;
        foreach ($materias_asignadas as $materia) {
            if ($materia['Id'] == $materia_id) {
                $materia_valida = true;
                break;
            }
        }
        
        if ($materia_valida) {
            $archivo = $_FILES['archivo'];
            
            if ($archivo['error'] === UPLOAD_ERR_OK) {
                $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
                $extensiones_permitidas = ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png'];
                
                if (in_array($extension, $extensiones_permitidas)) {
                    $nombre_archivo = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $archivo['name']);
                    $ruta_destino = '../assets/modelos_examen/' . $nombre_archivo;
                    
                    // Crear directorio si no existe
                    if (!is_dir('../assets/modelos_examen')) {
                        mkdir('../assets/modelos_examen', 0755, true);
                    }
                    
                    if (move_uploaded_file($archivo['tmp_name'], $ruta_destino)) {
                        $stmt = $pdo->prepare("INSERT INTO modelos_examen (profesor_id, materia_id, titulo, descripcion, archivo, fecha_subida, activo) VALUES (?, ?, ?, ?, ?, NOW(), 1)");
                        if ($stmt->execute([$_SESSION['usuario_id'], $materia_id, $titulo, $descripcion, $nombre_archivo])) {
                            $success = 'Modelo de examen subido correctamente';
                        } else {
                            $error = 'Error al guardar la información en la base de datos';
                            unlink($ruta_destino); // Eliminar archivo si falla la BD
                        }
                    } else {
                        $error = 'Error al subir el archivo';
                    }
                } else {
                    $error = 'Tipo de archivo no permitido. Use: PDF, DOC, DOCX, TXT, JPG, JPEG, PNG';
                }
            } else {
                $error = 'Error al subir el archivo';
            }
        } else {
            $error = 'No tiene permisos para subir modelos de esta materia';
        }
    } else {
        $error = 'Complete todos los campos y seleccione un archivo';
    }
}

// Obtener modelos subidos por el profesor
$stmt = $pdo->prepare("
    SELECT me.*, m.nombre as materia_nombre, m.especialidad, m.año as materia_año
    FROM modelos_examen me
    JOIN materias m ON me.materia_id = m.Id
    WHERE me.profesor_id = ? AND me.activo = 1
    ORDER BY me.fecha_subida DESC
");
$stmt->execute([$_SESSION['usuario_id']]);
$modelos_subidos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Modelos de Examen - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .table tr:hover {
            background-color: #f5f5f5;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .especialidad-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-right: 5px;
        }
        
        .especialidad-ciclo-basico {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .especialidad-programacion {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .especialidad-informatica {
            background: #e8f5e8;
            color: #388e3c;
        }
        
        .especialidad-alimentos {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .upload-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="perfil.php">Mi Perfil</a></li>
                    <li><a href="subir_modelo_examen.php">Subir Modelos</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <span>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="header">
                <h1>Subir Modelos de Examen</h1>
                <p>Comparte modelos de examen con tus estudiantes</p>
            </div>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="upload-section">
                <h3>Subir Nuevo Modelo</h3>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="materia_id">Materia:</label>
                        <select name="materia_id" id="materia_id" required>
                            <option value="">Seleccionar materia</option>
                            <?php foreach ($materias_asignadas as $materia): ?>
                                <option value="<?php echo $materia['Id']; ?>">
                                    <?php echo $materia['año']; ?>° - <?php echo htmlspecialchars($materia['nombre']); ?> 
                                    (<?php echo htmlspecialchars($materia['especialidad']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="titulo">Título del Modelo:</label>
                        <input type="text" name="titulo" id="titulo" required placeholder="Ej: Modelo de Examen Parcial - Primer Trimestre">
                    </div>
                    
                    <div class="form-group">
                        <label for="descripcion">Descripción (opcional):</label>
                        <textarea name="descripcion" id="descripcion" placeholder="Descripción del contenido del examen, temas incluidos, etc."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="archivo">Archivo:</label>
                        <input type="file" name="archivo" id="archivo" required accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png">
                        <small>Formatos permitidos: PDF, DOC, DOCX, TXT, JPG, JPEG, PNG</small>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Subir Modelo</button>
                </form>
            </div>
            
            <h3>Mis Modelos Subidos</h3>
            <?php if (empty($modelos_subidos)): ?>
                <p>No has subido ningún modelo de examen aún.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Materia</th>
                            <th>Especialidad</th>
                            <th>Año</th>
                            <th>Fecha de Subida</th>
                            <th>Archivo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($modelos_subidos as $modelo): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($modelo['titulo']); ?></td>
                            <td><?php echo htmlspecialchars($modelo['materia_nombre']); ?></td>
                            <td>
                                <span class="especialidad-badge especialidad-<?php echo strtolower(str_replace(' ', '-', $modelo['especialidad'])); ?>">
                                    <?php echo htmlspecialchars($modelo['especialidad']); ?>
                                </span>
                            </td>
                            <td><?php echo $modelo['materia_año']; ?>°</td>
                            <td><?php echo date('d/m/Y H:i', strtotime($modelo['fecha_subida'])); ?></td>
                            <td>
                                <a href="assets/modelos_examen/<?php echo htmlspecialchars($modelo['archivo']); ?>" target="_blank" class="btn">
                                    Ver Archivo
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Modelos de Examen</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
</body>
</html>
