<?php
require_once '../src/config.php';

$error = '';

if ($_POST) {
    $email = $_POST['email'] ?? '';
    $contraseña = $_POST['contraseña'] ?? '';
    
    if ($email && $contraseña) {
        // Buscar primero en directivos
        $stmt = $pdo->prepare("SELECT * FROM directivos WHERE email = ? AND contraseña = ?");
        $stmt->execute([$email, $contraseña]);
        $usuario = $stmt->fetch();
        
        if ($usuario) {
            $_SESSION['usuario_id'] = $usuario['Id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['tipo'] = 'director';
            header('Location: admin_panel.php');
            exit;
        }
        
        // Si no es director, buscar en profesores
        $stmt = $pdo->prepare("SELECT * FROM profesores WHERE email = ? AND contraseña = ? AND activo = 1");
        $stmt->execute([$email, $contraseña]);
        $usuario = $stmt->fetch();
        
        if ($usuario) {
            $_SESSION['usuario_id'] = $usuario['Id'];
            $_SESSION['nombre'] = $usuario['nombre'] . ' ' . $usuario['apellido'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['tipo'] = 'profesor';
            header('Location: profesor_panel.php');
            exit;
        }
        
        // Si no es profesor, buscar en alumnos
        $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE email = ? AND contraseña = ? AND activo = 1");
        $stmt->execute([$email, $contraseña]);
        $usuario = $stmt->fetch();
        
        if ($usuario) {
            $_SESSION['usuario_id'] = $usuario['Id'];
            $_SESSION['nombre'] = $usuario['nombre'] . ' ' . $usuario['apellido'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['tipo'] = 'alumno';
            header('Location: perfil.php');
            exit;
        }
        
        // Si no se encuentra en ninguna tabla
        $error = 'Credenciales incorrectas';
    } else {
        $error = 'Complete todos los campos';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
<body>
    <div class="login-container">
        
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="email">Email o Cargo:</label>
                <input type="text" name="email" id="email" required placeholder="Email para usuarios o cargo para administradores">
            </div>
            
            <div class="form-group">
                <label for="contraseña">Contraseña:</label>
                <input type="password" name="contraseña" id="contraseña" required>
            </div>
            
            <button type="submit" class="btn-login">Ingresar</button>
        </form>
        
        <div class="back-link">
            <a href="index.php">← Volver al inicio</a> | 
            <a href="registro.php">Crear cuenta</a>
        </div>
    </div>
</body>
</html>
