<?php
require_once '../src/config.php';

// Verificar que sea un director logueado
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'director') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// Procesar asignación/desasignación de materias
if ($_POST) {
    $profesor_id = $_POST['profesor_id'] ?? '';
    $materia_id = $_POST['materia_id'] ?? '';
    $accion = $_POST['accion'] ?? '';
    
    if ($profesor_id && $materia_id && $accion) {
        if ($accion === 'asignar') {
            // Verificar si ya está asignada
            $stmt = $pdo->prepare("SELECT Id FROM profesor_materia WHERE profesor_id = ? AND materia_id = ? AND activo = 1");
            $stmt->execute([$profesor_id, $materia_id]);
            
            if (!$stmt->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO profesor_materia (profesor_id, materia_id, año_academico, activo) VALUES (?, ?, ?, 1)");
                if ($stmt->execute([$profesor_id, $materia_id, date('Y')])) {
                    $success = 'Materia asignada correctamente al profesor';
                } else {
                    $error = 'Error al asignar la materia';
                }
            } else {
                $error = 'Esta materia ya está asignada al profesor';
            }
        } elseif ($accion === 'desasignar') {
            $stmt = $pdo->prepare("UPDATE profesor_materia SET activo = 0 WHERE profesor_id = ? AND materia_id = ?");
            if ($stmt->execute([$profesor_id, $materia_id])) {
                $success = 'Materia desasignada correctamente del profesor';
            } else {
                $error = 'Error al desasignar la materia';
            }
        }
    }
}

// Obtener todos los profesores activos
$stmt = $pdo->query("SELECT * FROM profesores WHERE activo = 1 ORDER BY apellido, nombre");
$profesores = $stmt->fetchAll();

// Obtener todas las materias activas
$stmt = $pdo->query("SELECT * FROM materias WHERE activa = 1 ORDER BY especialidad, año, nombre");
$materias = $stmt->fetchAll();

// Obtener asignaciones actuales
$stmt = $pdo->query("
    SELECT pm.*, p.nombre as profesor_nombre, p.apellido as profesor_apellido, 
           m.nombre as materia_nombre, m.especialidad, m.año, m.tipo
    FROM profesor_materia pm
    JOIN profesores p ON pm.profesor_id = p.Id
    JOIN materias m ON pm.materia_id = m.Id
    WHERE pm.activo = 1
    ORDER BY p.apellido, p.nombre, m.especialidad, m.año, m.nombre
");
$asignaciones = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Materias a Profesores - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1400px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 5px solid #3498db;
        }
        
        .dashboard-card h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.3em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .form-group select, .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ecf0f1;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        
        .form-group select:focus, .form-group input:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 25px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-danger {
            background: #e74c3c;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-secondary {
            background: #95a5a6;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #e74c3c;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #27ae60;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .table th, .table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .especialidad-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: bold;
            margin-right: 5px;
        }
        
        .especialidad-ciclo-basico {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .especialidad-programacion {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .especialidad-informatica {
            background: #e8f5e8;
            color: #388e3c;
        }
        
        .especialidad-alimentos {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .tipo-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .tipo-aula {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .tipo-taller {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .actions-section {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .action-form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .back-link {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .back-link a {
            display: inline-block;
            padding: 10px 20px;
            background: #95a5a6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .back-link a:hover {
            background: #7f8c8d;
        }
        
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="admin_panel.php">Panel Admin</a></li>
                    <li><a href="gestionar_profesores.php">Gestionar Profesores</a></li>
                    <li><a href="asignar_materias_profesor.php">Asignar Materias</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <a href="perfil.php" class="btn-perfil">Perfil</a>
                <a href="logout.php" class="btn-login">Cerrar Sesión</a>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="back-link">
                <a href="admin_panel.php">← Volver al Panel de Administración</a>
            </div>
            
            <div class="header">
                <h1>Asignar Materias a Profesores</h1>
                <p>Gestiona las asignaciones de materias a los profesores</p>
            </div>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="actions-section">
                <h3>Gestión de Asignaciones</h3>
                <div class="actions-grid">
                    <div class="action-form">
                        <h4>Asignar Materia</h4>
                        <form method="POST">
                            <input type="hidden" name="accion" value="asignar">
                            
                            <div class="form-group">
                                <label for="profesor_asignar">Profesor:</label>
                                <select name="profesor_id" id="profesor_asignar" required>
                                    <option value="">Seleccionar profesor</option>
                                    <?php foreach ($profesores as $profesor): ?>
                                        <option value="<?php echo $profesor['Id']; ?>">
                                            <?php echo htmlspecialchars($profesor['apellido'] . ', ' . $profesor['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="materia_asignar">Materia:</label>
                                <select name="materia_id" id="materia_asignar" required>
                                    <option value="">Seleccionar materia</option>
                                    <?php foreach ($materias as $materia): ?>
                                        <option value="<?php echo $materia['Id']; ?>">
                                            <?php echo $materia['año']; ?>° - <?php echo htmlspecialchars($materia['nombre']); ?> 
                                            (<?php echo htmlspecialchars($materia['especialidad']); ?> - <?php echo $materia['tipo']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-success">Asignar Materia</button>
                        </form>
                    </div>
                    
                    <div class="action-form">
                        <h4>Desasignar Materia</h4>
                        <form method="POST" onsubmit="return confirm('¿Está seguro de desasignar esta materia?')">
                            <input type="hidden" name="accion" value="desasignar">
                            
                            <div class="form-group">
                                <label for="profesor_desasignar">Profesor:</label>
                                <select name="profesor_id" id="profesor_desasignar" required>
                                    <option value="">Seleccionar profesor</option>
                                    <?php foreach ($profesores as $profesor): ?>
                                        <option value="<?php echo $profesor['Id']; ?>">
                                            <?php echo htmlspecialchars($profesor['apellido'] . ', ' . $profesor['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="materia_desasignar">Materia:</label>
                                <select name="materia_id" id="materia_desasignar" required>
                                    <option value="">Seleccionar materia</option>
                                    <?php foreach ($materias as $materia): ?>
                                        <option value="<?php echo $materia['Id']; ?>">
                                            <?php echo $materia['año']; ?>° - <?php echo htmlspecialchars($materia['nombre']); ?> 
                                            (<?php echo htmlspecialchars($materia['especialidad']); ?> - <?php echo $materia['tipo']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-danger">Desasignar Materia</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-card">
                <h3>Asignaciones Actuales</h3>
                
                <?php if (empty($asignaciones)): ?>
                    <p>No hay asignaciones de materias actualmente.</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Profesor</th>
                                <th>Materia</th>
                                <th>Especialidad</th>
                                <th>Año</th>
                                <th>Tipo</th>
                                <th>Año Académico</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($asignaciones as $asignacion): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($asignacion['profesor_apellido'] . ', ' . $asignacion['profesor_nombre']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($asignacion['materia_nombre']); ?></td>
                                <td>
                                    <span class="especialidad-badge especialidad-<?php echo strtolower(str_replace(' ', '-', $asignacion['especialidad'])); ?>">
                                        <?php echo htmlspecialchars($asignacion['especialidad']); ?>
                                    </span>
                                </td>
                                <td><?php echo $asignacion['año']; ?>°</td>
                                <td>
                                    <span class="tipo-badge tipo-<?php echo strtolower($asignacion['tipo']); ?>">
                                        <?php echo htmlspecialchars($asignacion['tipo']); ?>
                                    </span>
                                </td>
                                <td><?php echo $asignacion['año_academico']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Gestión de Asignaciones</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
</body>
</html>
