<?php
require_once '../src/config.php';

$materia_id = $_GET['id'] ?? '';

if (!$materia_id) {
    header('Location: index.php');
    exit;
}

// Obtener información de la materia
$stmt = $pdo->prepare("SELECT * FROM materias WHERE Id = ? AND activa = 1");
$stmt->execute([$materia_id]);
$materia = $stmt->fetch();

if (!$materia) {
    header('Location: index.php');
    exit;
}

// Obtener profesores asignados a esta materia
$stmt = $pdo->prepare("
    SELECT p.*, pm.año_academico
    FROM profesores p
    JOIN profesor_materia pm ON p.Id = pm.profesor_id
    WHERE pm.materia_id = ? AND pm.activo = 1 AND p.activo = 1
    ORDER BY p.apellido, p.nombre
");
$stmt->execute([$materia_id]);
$profesores = $stmt->fetchAll();

// Obtener modelos de examen para esta materia
$stmt = $pdo->prepare("
    SELECT me.*, p.nombre as profesor_nombre, p.apellido as profesor_apellido
    FROM modelos_examen me
    JOIN profesores p ON me.profesor_id = p.Id
    WHERE me.materia_id = ? AND me.activo = 1
    ORDER BY me.fecha_subida DESC
");
$stmt->execute([$materia_id]);
$modelos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($materia['nombre']); ?> - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .materia-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .materia-title {
            font-size: 1.5em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .materia-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .detail-item {
            background: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .detail-label {
            font-weight: bold;
            color: #7f8c8d;
            font-size: 0.9em;
            margin-bottom: 5px;
        }
        
        .detail-value {
            color: #2c3e50;
            font-size: 1.1em;
        }
        
        .tipo-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.9em;
            font-weight: bold;
        }
        
        .tipo-aula {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .tipo-taller {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .especialidad-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.9em;
            font-weight: bold;
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .section-title {
            font-size: 1.3em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ecf0f1;
        }
        
        .profesor-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #3498db;
        }
        
        .profesor-nombre {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .profesor-info {
            color: #7f8c8d;
            font-size: 0.9em;
        }
        
        .modelo-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #27ae60;
        }
        
        .modelo-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .modelo-titulo {
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
            margin: 0;
        }
        
        .modelo-fecha {
            color: #7f8c8d;
            font-size: 0.9em;
        }
        
        .modelo-info {
            margin-bottom: 15px;
        }
        
        .modelo-info p {
            margin: 5px 0;
            color: #555;
        }
        
        .modelo-descripcion {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-style: italic;
        }
        
        .modelo-actions {
            text-align: right;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-secondary {
            background: #95a5a6;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .no-content {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-style: italic;
        }
        
        .back-link {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .back-link a {
            display: inline-block;
            padding: 10px 20px;
            background: #95a5a6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .back-link a:hover {
            background: #7f8c8d;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="ciclo_basico.php">Ciclo Básico</a></li>
                    <li><a href="ciclo_superior.php">Ciclo Superior</a></li>
                    <li><a href="materias_programacion.php">Programación</a></li>
                    <li><a href="modelos_examen.php">Modelos de Examen</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="back-link">
                <a href="materias_programacion.php">← Volver a Programación</a>
            </div>
            
            <div class="materia-info">
                <div class="materia-title"><?php echo htmlspecialchars($materia['nombre']); ?></div>
                
                <div class="materia-details">
                    <div class="detail-item">
                        <div class="detail-label">Año</div>
                        <div class="detail-value"><?php echo $materia['año']; ?>° Año</div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">Especialidad</div>
                        <div class="detail-value">
                            <span class="especialidad-badge"><?php echo htmlspecialchars($materia['especialidad']); ?></span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">Categoría</div>
                        <div class="detail-value"><?php echo htmlspecialchars($materia['categoria']); ?></div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">Tipo</div>
                        <div class="detail-value">
                            <span class="tipo-badge tipo-<?php echo strtolower($materia['tipo']); ?>">
                                <?php echo htmlspecialchars($materia['tipo']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">Carga Horaria Total</div>
                        <div class="detail-value"><?php echo $materia['cht']; ?> CHT</div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">Carga Horaria Semanal</div>
                        <div class="detail-value"><?php echo $materia['chs']; ?> CHS</div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Profesores Asignados</div>
                
                <?php if (empty($profesores)): ?>
                    <div class="no-content">
                        <p>No hay profesores asignados a esta materia actualmente.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($profesores as $profesor): ?>
                    <div class="profesor-card">
                        <div class="profesor-nombre">
                            <?php echo htmlspecialchars($profesor['apellido'] . ', ' . $profesor['nombre']); ?>
                        </div>
                        <div class="profesor-info">
                            <strong>Email:</strong> <?php echo htmlspecialchars($profesor['email']); ?><br>
                            <?php if ($profesor['telefono']): ?>
                                <strong>Teléfono:</strong> <?php echo htmlspecialchars($profesor['telefono']); ?><br>
                            <?php endif; ?>
                            <strong>Año Académico:</strong> <?php echo $profesor['año_academico']; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="section">
                <div class="section-title">Modelos de Examen</div>
                
                <?php if (empty($modelos)): ?>
                    <div class="no-content">
                        <p>No hay modelos de examen disponibles para esta materia.</p>
                        <p>Los profesores pueden subir modelos de examen desde su panel.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($modelos as $modelo): ?>
                    <div class="modelo-card">
                        <div class="modelo-header">
                            <h3 class="modelo-titulo"><?php echo htmlspecialchars($modelo['titulo']); ?></h3>
                            <span class="modelo-fecha"><?php echo date('d/m/Y H:i', strtotime($modelo['fecha_subida'])); ?></span>
                        </div>
                        
                        <div class="modelo-info">
                            <p><strong>Profesor:</strong> <?php echo htmlspecialchars($modelo['profesor_apellido'] . ', ' . $modelo['profesor_nombre']); ?></p>
                            <p><strong>Archivo:</strong> <?php echo htmlspecialchars($modelo['archivo']); ?></p>
                        </div>
                        
                        <?php if ($modelo['descripcion']): ?>
                        <div class="modelo-descripcion">
                            <strong>Descripción:</strong><br>
                            <?php echo nl2br(htmlspecialchars($modelo['descripcion'])); ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="modelo-actions">
                            <a href="assets/modelos_examen/<?php echo htmlspecialchars($modelo['archivo']); ?>" 
                               target="_blank" class="btn btn-success">
                                📄 Ver Modelo de Examen
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p><?php echo htmlspecialchars($materia['nombre']); ?></p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
</body>
</html>
