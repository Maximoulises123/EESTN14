<?php
require_once '../src/config.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Obtener información del usuario
$usuario_tipo = $_SESSION['tipo'] ?? '';
$usuario_id = $_SESSION['usuario_id'];

// Obtener materias del usuario según su tipo
$materias_usuario = [];

if ($usuario_tipo === 'alumno') {
    // Obtener materias del alumno
    $stmt = $pdo->prepare("
        SELECT m.*, am.año_academico
        FROM materias m
        JOIN alumno_materia am ON m.Id = am.materia_id
        WHERE am.alumno_id = ? AND am.activo = 1 AND m.activa = 1
        ORDER BY m.especialidad, m.año, m.nombre
    ");
    $stmt->execute([$usuario_id]);
    $materias_usuario = $stmt->fetchAll();
} elseif ($usuario_tipo === 'profesor') {
    // Obtener materias del profesor
    $stmt = $pdo->prepare("
        SELECT m.*, pm.año_academico
        FROM materias m
        JOIN profesor_materia pm ON m.Id = pm.materia_id
        WHERE pm.profesor_id = ? AND pm.activo = 1 AND m.activa = 1
        ORDER BY m.especialidad, m.año, m.nombre
    ");
    $stmt->execute([$usuario_id]);
    $materias_usuario = $stmt->fetchAll();
} elseif ($usuario_tipo === 'director') {
    // El director puede ver todos los modelos
    $stmt = $pdo->query("
        SELECT DISTINCT m.*
        FROM materias m
        WHERE m.activa = 1
        ORDER BY m.especialidad, m.año, m.nombre
    ");
    $materias_usuario = $stmt->fetchAll();
}

// Obtener modelos de examen
$modelos = [];
if (!empty($materias_usuario)) {
    $materia_ids = array_column($materias_usuario, 'Id');
    $placeholders = str_repeat('?,', count($materia_ids) - 1) . '?';
    
    $stmt = $pdo->prepare("
        SELECT me.*, m.nombre as materia_nombre, m.especialidad, m.año as materia_año,
               p.nombre as profesor_nombre, p.apellido as profesor_apellido
        FROM modelos_examen me
        JOIN materias m ON me.materia_id = m.Id
        JOIN profesores p ON me.profesor_id = p.Id
        WHERE me.materia_id IN ($placeholders) AND me.activo = 1
        ORDER BY m.especialidad, m.año, m.nombre, me.fecha_subida DESC
    ");
    $stmt->execute($materia_ids);
    $modelos = $stmt->fetchAll();
}

// Filtrar por especialidad si se especifica
$especialidad_filtro = $_GET['especialidad'] ?? '';
if ($especialidad_filtro) {
    $modelos = array_filter($modelos, function($modelo) use ($especialidad_filtro) {
        return $modelo['especialidad'] === $especialidad_filtro;
    });
}

// Obtener especialidades únicas para el filtro
$especialidades = array_unique(array_column($modelos, 'especialidad'));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modelos de Examen - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .filters {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .filter-group {
            display: inline-block;
            margin-right: 20px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .filter-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .table tr:hover {
            background-color: #f5f5f5;
        }
        
        .especialidad-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-right: 5px;
        }
        
        .especialidad-ciclo-basico {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .especialidad-programacion {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .especialidad-informatica {
            background: #e8f5e8;
            color: #388e3c;
        }
        
        .especialidad-alimentos {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .no-models {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-style: italic;
        }
        
        .model-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #3498db;
        }
        
        .model-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .model-title {
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
            margin: 0;
        }
        
        .model-date {
            color: #7f8c8d;
            font-size: 0.9em;
        }
        
        .model-info {
            margin-bottom: 15px;
        }
        
        .model-info p {
            margin: 5px 0;
            color: #555;
        }
        
        .model-description {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-style: italic;
        }
        
        .model-actions {
            text-align: right;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="perfil.php">Mi Perfil</a></li>
                    <li><a href="modelos_examen.php">Modelos de Examen</a></li>
                    <?php if ($usuario_tipo === 'profesor'): ?>
                        <li><a href="subir_modelo_examen.php">Subir Modelos</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <span>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="header">
                <h1>Modelos de Examen</h1>
                <p>Consulta los modelos de examen disponibles para tus materias</p>
            </div>
            
            <?php if (!empty($especialidades)): ?>
            <div class="filters">
                <div class="filter-group">
                    <label for="especialidad">Filtrar por especialidad:</label>
                    <select id="especialidad" onchange="filtrarEspecialidad()">
                        <option value="">Todas las especialidades</option>
                        <?php foreach ($especialidades as $especialidad): ?>
                            <option value="<?php echo htmlspecialchars($especialidad); ?>" 
                                    <?php echo $especialidad_filtro === $especialidad ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($especialidad); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (empty($modelos)): ?>
                <div class="no-models">
                    <h3>No hay modelos de examen disponibles</h3>
                    <p>No se encontraron modelos de examen para tus materias asignadas.</p>
                </div>
            <?php else: ?>
                <?php foreach ($modelos as $modelo): ?>
                <div class="model-card">
                    <div class="model-header">
                        <h3 class="model-title"><?php echo htmlspecialchars($modelo['titulo']); ?></h3>
                        <span class="model-date"><?php echo date('d/m/Y H:i', strtotime($modelo['fecha_subida'])); ?></span>
                    </div>
                    
                    <div class="model-info">
                        <p><strong>Materia:</strong> <?php echo htmlspecialchars($modelo['materia_nombre']); ?></p>
                        <p><strong>Especialidad:</strong> 
                            <span class="especialidad-badge especialidad-<?php echo strtolower(str_replace(' ', '-', $modelo['especialidad'])); ?>">
                                <?php echo htmlspecialchars($modelo['especialidad']); ?>
                            </span>
                        </p>
                        <p><strong>Año:</strong> <?php echo $modelo['materia_año']; ?>°</p>
                        <p><strong>Profesor:</strong> <?php echo htmlspecialchars($modelo['profesor_apellido'] . ', ' . $modelo['profesor_nombre']); ?></p>
                    </div>
                    
                    <?php if ($modelo['descripcion']): ?>
                    <div class="model-description">
                        <strong>Descripción:</strong><br>
                        <?php echo nl2br(htmlspecialchars($modelo['descripcion'])); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="model-actions">
                        <a href="assets/modelos_examen/<?php echo htmlspecialchars($modelo['archivo']); ?>" 
                           target="_blank" class="btn btn-success">
                            📄 Ver Modelo de Examen
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Modelos de Examen</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
    
    <script>
        function filtrarEspecialidad() {
            const especialidad = document.getElementById('especialidad').value;
            const url = new URL(window.location);
            
            if (especialidad) {
                url.searchParams.set('especialidad', especialidad);
            } else {
                url.searchParams.delete('especialidad');
            }
            
            window.location.href = url.toString();
        }
    </script>
</body>
</html>
