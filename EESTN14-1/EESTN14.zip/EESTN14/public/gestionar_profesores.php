<?php
require_once '../src/config.php';

// Verificar si el usuario es director
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'director') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// Procesar acciones
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'crear_profesor') {
        $nombre = trim($_POST['nombre'] ?? '');
        $apellido = trim($_POST['apellido'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $contraseña = $_POST['contraseña'] ?? '';
        
        if ($nombre && $apellido && $email && $contraseña) {
            // Verificar si el email ya existe
            $stmt = $pdo->prepare("SELECT Id FROM profesores WHERE email = ?");
            $stmt->execute([$email]);
            
            if (!$stmt->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO profesores (nombre, apellido, email, telefono, contraseña, fecha_registro) VALUES (?, ?, ?, ?, ?, NOW())");
                if ($stmt->execute([$nombre, $apellido, $email, $telefono, $contraseña])) {
                    $success = 'Profesor creado correctamente';
                } else {
                    $error = 'Error al crear el profesor';
                }
            } else {
                $error = 'El email ya está registrado';
            }
        } else {
            $error = 'Complete todos los campos obligatorios';
        }
    }
    
    if ($action === 'editar_profesor') {
        $id = $_POST['id'] ?? '';
        $nombre = trim($_POST['nombre'] ?? '');
        $apellido = trim($_POST['apellido'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $activo = $_POST['activo'] ?? 0;
        
        if ($id && $nombre && $apellido && $email) {
            $stmt = $pdo->prepare("UPDATE profesores SET nombre = ?, apellido = ?, email = ?, telefono = ?, activo = ? WHERE Id = ?");
            if ($stmt->execute([$nombre, $apellido, $email, $telefono, $activo, $id])) {
                $success = 'Profesor actualizado correctamente';
            } else {
                $error = 'Error al actualizar el profesor';
            }
        } else {
            $error = 'Complete todos los campos obligatorios';
        }
    }
    
    if ($action === 'eliminar_profesor') {
        $id = $_POST['id'] ?? '';
        
        if ($id) {
            $stmt = $pdo->prepare("UPDATE profesores SET activo = 0 WHERE Id = ?");
            if ($stmt->execute([$id])) {
                $success = 'Profesor desactivado correctamente';
            } else {
                $error = 'Error al desactivar el profesor';
            }
        }
    }
}

// Obtener lista de profesores
$stmt = $pdo->query("SELECT * FROM profesores ORDER BY apellido, nombre");
$profesores = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Profesores - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-danger {
            background: #e74c3c;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .table tr:hover {
            background-color: #f5f5f5;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 500px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .status-activo {
            color: #27ae60;
            font-weight: bold;
        }
        
        .status-inactivo {
            color: #e74c3c;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="admin_panel.php">Panel Admin</a></li>
                    <li><a href="gestionar_profesores.php">Profesores</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <span>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="header">
                <h1>Gestión de Profesores</h1>
                <p>Administra los profesores de la institución</p>
            </div>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div style="text-align: center; margin-bottom: 20px;">
                <button onclick="abrirModalCrear()" class="btn btn-success">Crear Nuevo Profesor</button>
                <a href="admin_panel.php" class="btn">Volver al Panel</a>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($profesores as $profesor): ?>
                    <tr>
                        <td><?php echo $profesor['Id']; ?></td>
                        <td><?php echo htmlspecialchars($profesor['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($profesor['apellido']); ?></td>
                        <td><?php echo htmlspecialchars($profesor['email']); ?></td>
                        <td><?php echo htmlspecialchars($profesor['telefono'] ?? 'No especificado'); ?></td>
                        <td>
                            <span class="<?php echo $profesor['activo'] ? 'status-activo' : 'status-inactivo'; ?>">
                                <?php echo $profesor['activo'] ? 'Activo' : 'Inactivo'; ?>
                            </span>
                        </td>
                        <td>
                            <button onclick="editarProfesor(<?php echo htmlspecialchars(json_encode($profesor)); ?>)" class="btn">Editar</button>
                            <?php if ($profesor['activo']): ?>
                                <button onclick="eliminarProfesor(<?php echo $profesor['Id']; ?>)" class="btn btn-danger">Desactivar</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <!-- Modal para crear profesor -->
    <div id="modalCrear" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarModalCrear()">&times;</span>
            <h3>Crear Nuevo Profesor</h3>
            <form method="POST">
                <input type="hidden" name="action" value="crear_profesor">
                
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" name="nombre" id="nombre" required>
                </div>
                
                <div class="form-group">
                    <label for="apellido">Apellido:</label>
                    <input type="text" name="apellido" id="apellido" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" required>
                </div>
                
                <div class="form-group">
                    <label for="telefono">Teléfono (opcional):</label>
                    <input type="text" name="telefono" id="telefono">
                </div>
                
                <div class="form-group">
                    <label for="contraseña">Contraseña:</label>
                    <input type="password" name="contraseña" id="contraseña" required>
                </div>
                
                <button type="submit" class="btn btn-success">Crear Profesor</button>
            </form>
        </div>
    </div>
    
    <!-- Modal para editar profesor -->
    <div id="modalEditar" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarModalEditar()">&times;</span>
            <h3>Editar Profesor</h3>
            <form method="POST">
                <input type="hidden" name="action" value="editar_profesor">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label for="edit_nombre">Nombre:</label>
                    <input type="text" name="nombre" id="edit_nombre" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_apellido">Apellido:</label>
                    <input type="text" name="apellido" id="edit_apellido" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_email">Email:</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_telefono">Teléfono:</label>
                    <input type="text" name="telefono" id="edit_telefono">
                </div>
                
                <div class="form-group">
                    <label for="edit_activo">Estado:</label>
                    <select name="activo" id="edit_activo">
                        <option value="1">Activo</option>
                        <option value="0">Inactivo</option>
                    </select>
                </div>
                
                <button type="submit" class="btn">Actualizar Profesor</button>
            </form>
        </div>
    </div>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Gestión de Profesores</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
    
    <script>
        function abrirModalCrear() {
            document.getElementById('modalCrear').style.display = 'block';
        }
        
        function cerrarModalCrear() {
            document.getElementById('modalCrear').style.display = 'none';
        }
        
        function editarProfesor(profesor) {
            document.getElementById('edit_id').value = profesor.Id;
            document.getElementById('edit_nombre').value = profesor.nombre;
            document.getElementById('edit_apellido').value = profesor.apellido;
            document.getElementById('edit_email').value = profesor.email;
            document.getElementById('edit_telefono').value = profesor.telefono || '';
            document.getElementById('edit_activo').value = profesor.activo;
            document.getElementById('modalEditar').style.display = 'block';
        }
        
        function cerrarModalEditar() {
            document.getElementById('modalEditar').style.display = 'none';
        }
        
        function eliminarProfesor(id) {
            if (confirm('¿Está seguro de que desea desactivar este profesor?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="eliminar_profesor">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Cerrar modales al hacer clic fuera
        window.onclick = function(event) {
            const modalCrear = document.getElementById('modalCrear');
            const modalEditar = document.getElementById('modalEditar');
            
            if (event.target === modalCrear) {
                modalCrear.style.display = 'none';
            }
            if (event.target === modalEditar) {
                modalEditar.style.display = 'none';
            }
        }
    </script>
</body>
</html>
