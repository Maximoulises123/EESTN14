<?php
require_once '../src/config.php';

// Verificar que sea un profesor logueado
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'profesor') {
    header('Location: login.php');
    exit;
}

$profesor_id = $_SESSION['usuario_id'];

// Obtener información del profesor
$stmt = $pdo->prepare("SELECT * FROM profesores WHERE Id = ?");
$stmt->execute([$profesor_id]);
$profesor = $stmt->fetch();

// Obtener materias asignadas al profesor
$stmt = $pdo->prepare("
    SELECT m.*, pm.año_academico
    FROM materias m
    JOIN profesor_materia pm ON m.Id = pm.materia_id
    WHERE pm.profesor_id = ? AND pm.activo = 1 AND m.activa = 1
    ORDER BY m.año, m.nombre
");
$stmt->execute([$profesor_id]);
$materias_asignadas = $stmt->fetchAll();

// Obtener modelos de examen subidos por el profesor
$stmt = $pdo->prepare("
    SELECT me.*, m.nombre as materia_nombre
    FROM modelos_examen me
    JOIN materias m ON me.materia_id = m.Id
    WHERE me.profesor_id = ? AND me.activo = 1
    ORDER BY me.fecha_subida DESC
");
$stmt->execute([$profesor_id]);
$modelos_subidos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel del Profesor - EEST14</title>
    <link rel="stylesheet" href="assets/css/encabezado.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .welcome-card {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .welcome-card h2 {
            margin: 0 0 10px 0;
            font-size: 1.8em;
        }
        
        .welcome-card p {
            margin: 0;
            opacity: 0.9;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 5px solid #3498db;
        }
        
        .dashboard-card h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.3em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-icon {
            font-size: 1.5em;
        }
        
        .materia-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #27ae60;
        }
        
        .materia-nombre {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .materia-info {
            font-size: 0.9em;
            color: #7f8c8d;
            margin-bottom: 10px;
        }
        
        .materia-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9em;
            font-weight: bold;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
        }
        
        .modelo-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #f39c12;
        }
        
        .modelo-titulo {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .modelo-info {
            font-size: 0.9em;
            color: #7f8c8d;
            margin-bottom: 10px;
        }
        
        .modelo-fecha {
            font-size: 0.8em;
            color: #95a5a6;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #3498db;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #7f8c8d;
            font-size: 0.9em;
        }
        
        .no-content {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-style: italic;
        }
        
        .back-link {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .back-link a {
            display: inline-block;
            padding: 10px 20px;
            background: #95a5a6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .back-link a:hover {
            background: #7f8c8d;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="assets/img/LOGO.png" alt="E.E.S.T. N° 14 - GONZÁLEZ CATÁN" class="logo-img">
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="profesor_panel.php">Mi Panel</a></li>
                    <li><a href="modelos_examen.php">Modelos de Examen</a></li>
                    <li><a href="perfil.php">Mi Perfil</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <a href="perfil.php" class="btn-perfil">Perfil</a>
                <a href="logout.php" class="btn-login">Cerrar Sesión</a>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="back-link">
                <a href="index.php">← Volver al Inicio</a>
            </div>
            
            <div class="welcome-card">
                <h2>¡Bienvenido, Prof. <?php echo htmlspecialchars($profesor['apellido'] . ', ' . $profesor['nombre']); ?>!</h2>
                <p>Panel de gestión de materias y modelos de examen</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo count($materias_asignadas); ?></div>
                    <div class="stat-label">Materias Asignadas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo count($modelos_subidos); ?></div>
                    <div class="stat-label">Modelos Subidos</div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3><span class="card-icon">📚</span> Mis Materias</h3>
                    
                    <?php if (empty($materias_asignadas)): ?>
                        <div class="no-content">
                            <p>No tienes materias asignadas actualmente.</p>
                            <p>Contacta al director para que te asigne materias.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($materias_asignadas as $materia): ?>
                        <div class="materia-item">
                            <div class="materia-nombre"><?php echo htmlspecialchars($materia['nombre']); ?></div>
                            <div class="materia-info">
                                <strong>Año:</strong> <?php echo $materia['año']; ?>° | 
                                <strong>Tipo:</strong> <?php echo $materia['tipo']; ?> | 
                                <strong>CHS:</strong> <?php echo $materia['chs']; ?>
                            </div>
                            <div class="materia-actions">
                                <a href="subir_modelo_examen.php?materia_id=<?php echo $materia['Id']; ?>" class="btn btn-primary">
                                    📄 Subir Modelo
                                </a>
                                <a href="materia_detalle.php?id=<?php echo $materia['Id']; ?>" class="btn btn-info">
                                    👁️ Ver Detalles
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div class="dashboard-card">
                    <h3><span class="card-icon">📋</span> Mis Modelos de Examen</h3>
                    
                    <?php if (empty($modelos_subidos)): ?>
                        <div class="no-content">
                            <p>No has subido ningún modelo de examen aún.</p>
                            <p>Usa el botón "Subir Modelo" en tus materias para comenzar.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($modelos_subidos as $modelo): ?>
                        <div class="modelo-item">
                            <div class="modelo-titulo"><?php echo htmlspecialchars($modelo['titulo']); ?></div>
                            <div class="modelo-info">
                                <strong>Materia:</strong> <?php echo htmlspecialchars($modelo['materia_nombre']); ?><br>
                                <strong>Archivo:</strong> <?php echo htmlspecialchars($modelo['archivo']); ?>
                            </div>
                            <div class="modelo-fecha">
                                Subido el <?php echo date('d/m/Y H:i', strtotime($modelo['fecha_subida'])); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="dashboard-card">
                <h3><span class="card-icon">⚡</span> Acciones Rápidas</h3>
                <div class="materia-actions">
                    <a href="subir_modelo_examen.php" class="btn btn-success">
                        📄 Subir Nuevo Modelo de Examen
                    </a>
                    <a href="modelos_examen.php" class="btn btn-info">
                        👁️ Ver Todos los Modelos
                    </a>
                    <a href="perfil.php" class="btn btn-primary">
                        👤 Mi Perfil
                    </a>
                </div>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>E.E.S.T. N°14</h3>
                    <p>Panel del Profesor</p>
                </div>
            </div>
            <div class="footer-separator"></div>
            <div class="footer-bottom">
                <p>© 2024 E.E.S.T. N°14</p>
            </div>
        </div>
    </footer>
</body>
</html>
